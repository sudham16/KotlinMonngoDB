
rootProject.name = "KotlinMongoDB"

